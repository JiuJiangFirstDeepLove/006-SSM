package club.dao;

import club.pojo.Pet;
import com.baomidou.mybatisplus.mapper.BaseMapper;

public interface PetMapper extends BaseMapper<Pet> {

}
