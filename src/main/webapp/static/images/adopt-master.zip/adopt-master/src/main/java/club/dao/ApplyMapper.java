package club.dao;

import club.pojo.Apply;
import com.baomidou.mybatisplus.mapper.BaseMapper;

public interface ApplyMapper extends BaseMapper<Apply> {

}
