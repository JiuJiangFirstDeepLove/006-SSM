package club.dao;

import club.pojo.Answer;
import com.baomidou.mybatisplus.mapper.BaseMapper;

public interface AnswerMapper extends BaseMapper<Answer> {

}
