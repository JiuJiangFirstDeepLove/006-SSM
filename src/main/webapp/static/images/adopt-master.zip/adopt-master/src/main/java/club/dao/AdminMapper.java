package club.dao;

import club.pojo.Admins;
import com.baomidou.mybatisplus.mapper.BaseMapper;


public interface AdminMapper extends BaseMapper<Admins> {
}
