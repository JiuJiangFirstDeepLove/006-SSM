package club.dao;

import club.pojo.Comment;
import com.baomidou.mybatisplus.mapper.BaseMapper;

public interface CommentMapper extends BaseMapper<Comment> {

}
